# Telemed Aura

A full-stack telehealth portfolio demo featuring a patient dashboard, clinician listings, appointment booking, and rules-based symptom guidance.

## Features

- Responsive React and TypeScript patient dashboard
- Express REST API with request validation
- SQLite-backed appointment booking
- Rules-based educational symptom guidance with emergency messaging
- Vite development proxy and configurable production API URL

## Tech stack

React, TypeScript, Vite, Node.js, Express, Zod, SQLite

## Run locally

Backend (Terminal 1):

```bash
cd backend/src
npm install
npm run dev
```

Frontend (Terminal 2):

```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`.

## Deploy on Render

Create an API Web Service from this GitHub repository:

- Root Directory: `backend/src`
- Build Command: `npm install && npm run build`
- Start Command: `npm start`

After it deploys, note the API's `onrender.com` URL.

Create a Static Site from the same repository:

- Root Directory: `frontend`
- Build Command: `npm install && npm run build`
- Publish Directory: `dist`
- Environment Variable: `VITE_API_URL` = the API URL from the previous step

Then set `CLIENT_ORIGIN` on the API service to the frontend Static Site URL and redeploy the API.

For a persistent SQLite file, attach a persistent disk to the API service, mount it at `/var/data`, and set `DB_PATH` to `/var/data/telemed-aura.db`. Without persistent storage, appointment changes can be lost when the service restarts or redeploys.

## Demo scope

This is a portfolio demo, not a clinical product. Symptom guidance is rules-based and educational, not AI diagnosis or medical advice. Do not enter real patient information.
